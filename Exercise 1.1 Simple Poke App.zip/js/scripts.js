alert('Welcome to the Poke app');

let favoriteFood="pizza";
document.write(favoriteFood);
